import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
from nav_msgs.msg import Odometry
import math
import time

class PlanningNode(Node):
    def __init__(self):
        super().__init__('planning_node')

        # Parameters
        self.declare_parameter('mode', 'empty_world')
        self.declare_parameter('cruise_speed', 0.6)

        self.mode = str(self.get_parameter('mode').value)
        self.cruise_speed = float(self.get_parameter('cruise_speed').value)

        # Publishers
        self.speed_pub = self.create_publisher(Float64, '/desired_speed', 10)
        self.desired_x_pub = self.create_publisher(Float64, '/desired_x', 10)
        self.desired_y_pub = self.create_publisher(Float64, '/desired_y', 10)
        self.heading_pub = self.create_publisher(Float64, '/desired_heading', 10)
        
        # Subscriber
        self.create_subscription(Odometry, '/odom', self.odom_cb, 10)

        # State
        self.x, self.y, self.yaw = 0.0, 0.0, 0.0
        self.state = 0
        self._last_log = 0.0
        
        self.timer = self.create_timer(0.02, self.loop)
        self.get_logger().info(f"Planning Node Started - Mode: {self.mode}")

    def odom_cb(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        o = msg.pose.pose.orientation
        self.yaw = math.atan2(2.0 * (o.w * o.z + o.x * o.y), 1.0 - 2.0 * (o.y * o.y + o.z * o.z))

    def loop(self):
        des_x = 0.0
        des_y = 0.0
        des_speed = self.cruise_speed
        heading = 0.0

        # ============================================
        # EMPTY WORLD - Straight 10m
        # ============================================
        if self.mode == 'empty_world':
            des_x = 3.0
            des_y = 0.0
            if self.x > 9.5:
                des_speed = 0.0

        # ============================================
        # RACETRACK - Lane switches
        # ============================================
        elif self.mode == 'racetrack':
            # === EDIT THESE VALUES ===
            x1, y1 = 1.5, 0.15    # State 0
            x2, y2 = 4.0, 0.07    # State 1
            x3, y3 = 7.0, 0.5    # State 2
            x4, y4 = 10.0, 0.7    # State 3
            x_stop = 10.5
            threshold = 0.1

            if self.state == 0:
                des_x, des_y = x1, y1
                if self.x > x1 - threshold:
                    self.state = 1
                    self.get_logger().info("STATE 0→1")

            elif self.state == 1:
                des_x, des_y = x2, y2
                if self.x > x2 - threshold:
                    self.state = 2
                    self.get_logger().info("STATE 1→2")

            elif self.state == 2:
                des_x, des_y = x3, y3
                if self.x > x3 - threshold:
                    self.state = 3
                    self.get_logger().info("STATE 2→3")

            elif self.state == 3:
                des_x, des_y = x4, y4
                if self.x > x4 - threshold:
                    self.state = 4
                    self.get_logger().info("STATE 3→4 (STOP)")

            elif self.state == 4:
                des_x, des_y, des_speed = x_stop, y4, 0.0

            if self.state < 4:
                heading = math.atan2(des_y - self.y, des_x - self.x)
            else:
                heading = self.yaw

        # ============================================
        # CITY - Segments with rotations
        # ============================================

        elif self.mode == 'city':
            # === EDIT SEGMENT TARGETS ===
            segments = [
                (1.6 , 0.0, 0),# move forward 2
                (2.4 , 0.7, 1.57), #rotate
                #2
                (2.4 , 0.7, 1.57),# move forward 2 
                (1.75, 4.4, -3.06),#rotate
                #3
                (-2.0, 4.4, -3.06), # move forward 3
                (-2.5, 3.2, -1.71),#rotate
                #4
                (-2.5, 1.2, -1.71),# move forward 2
                (-2.0, 0.0, 0),  # rotate
                (0.0, 0.0, 0) # move to 0 and stop in range 
            ]

            if self.state < len(segments):
                x_target, y_target, yaw_target = segments[self.state]  # CHANGED: unpack yaw too
                des_x, des_y = x_target, y_target

                dist = math.sqrt((self.x - des_x)**2 + (self.y - des_y)**2)
                if dist < 0.3:
                    self.state += 1
                    self.get_logger().info(f"SEGMENT {self.state-1}→{self.state}")
            else:
                des_speed = 0.0
            
            heading = yaw_target  
            

        # Publish
        self.desired_x_pub.publish(Float64(data=float(des_x)))
        self.desired_y_pub.publish(Float64(data=float(des_y)))
        self.speed_pub.publish(Float64(data=float(des_speed)))
        self.heading_pub.publish(Float64(data=float(heading)))

        # Log every 1 second
        now = time.time()
        if (now - self._last_log) > 1.0:
            self.get_logger().info(
                f"[{self.mode}] State={self.state} | Pos=({self.x:.2f}, {self.y:.2f}) | "
                f"Target=({des_x:.2f}, {des_y:.2f}) | Speed={des_speed:.2f}"
            )
            self._last_log = now

def main():
    rclpy.init()
    node = PlanningNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
