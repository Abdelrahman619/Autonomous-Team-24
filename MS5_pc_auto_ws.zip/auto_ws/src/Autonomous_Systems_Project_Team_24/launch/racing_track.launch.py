import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable
from launch_ros.actions import Node

def generate_launch_description():
    model_path = os.path.expanduser('~/auto_ws/src/locomotion_pkg/models')
    world_path = os.path.expanduser('~/auto_ws/src/Autonomous_Systems_Project_Team_24/Worlds')
    
    # CRITICAL FIX: Matches your exact XML world file name case-sensitive
    world_file = os.path.join(world_path, 'Racing_Track.world') 
    sdf_file = os.path.join(model_path, 'car.sdf')

    sim_params = [{'use_sim_time': True, 'mode': 'racetrack'}]

    return LaunchDescription([
        SetEnvironmentVariable('GZ_SIM_RESOURCE_PATH', model_path + ':' + os.path.expanduser('~/.gz/models')),

        # 1. Gazebo Sim (Racing Track)
        ExecuteProcess(cmd=['gz', 'sim', '-r', world_file], output='screen'),

        # 2. Spawn Vehicle
        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=['-file', sdf_file, '-name', 'vehicle_blue', '-x', '0.0', '-y', '0.0', '-z', '0.35'],
            output='screen'
        ),

        # 3. Bridge (Odom and Cmd_vel connection to Gazebo)
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=[
                '/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                '/model/vehicle_blue/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
                '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'
            ],
            remappings=[
                ('/model/vehicle_blue/cmd_vel', '/cmd_vel'),
                ('/model/vehicle_blue/odometry', '/odom')
            ],
            output='screen'
        ),

        # 4. Speed Control (PID)
        Node(
            package='navigation_pkg', 
            executable='speed_control',
            name='speed_ctrl',
            parameters=sim_params,
            remappings=[('/cmd_vel', '/speed_effort')],
            output='screen'
        ),

        # 5. Lateral Control (Stanley)
        Node(
            package='navigation_pkg', 
            executable='lateral_control',
            name='lateral_ctrl',
            parameters=sim_params,
            output='screen'
        ),

        # 6. Planning Node (Race Mode)
        Node(
            package='navigation_pkg', 
            executable='planning_node',
            name='planner',
            parameters=[{
                'use_sim_time': True,
                'mode': 'racetrack',
                'cruise_speed': 0.5 
            }],
            output='screen'
        )
    ])
