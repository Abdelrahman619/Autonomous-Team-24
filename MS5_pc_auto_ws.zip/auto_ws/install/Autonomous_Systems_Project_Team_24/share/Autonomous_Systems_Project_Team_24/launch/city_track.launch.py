import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable
from launch_ros.actions import Node

def generate_launch_description():
    model_path = os.path.expanduser('~/auto_ws/src/locomotion_pkg/models')
    world_path = os.path.expanduser('~/auto_ws/src/Autonomous_Systems_Project_Team_24/Worlds')
    
    # RAGGA3NA EL PATH LEL CITY MAP WORLD FILE
    world_file = os.path.join(world_path, 'City_Track.world') 
    sdf_file = os.path.join(model_path, 'car.sdf')

    sim_params = [{'use_sim_time': True, 'mode': 'city'}]

    return LaunchDescription([
        SetEnvironmentVariable('GZ_SIM_RESOURCE_PATH', model_path + ':' + os.path.expanduser('~/.gz/models')),

        # 1. Gazebo Sim (City Map)
        ExecuteProcess(cmd=['gz', 'sim', '-r', world_file], output='screen'),

        # 2. Spawn Vehicle
        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=['-file', sdf_file, '-name', 'vehicle_blue', '-x', '0.0', '-y', '-1.75', '-z', '0.35'],
            output='screen'
        ),

        # 3. Bridge (Connects ROS to Gazebo directly for Odom/Cmd_vel)
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=[
                '/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                '/model/vehicle_blue/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
                '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'
            ],
            remappings=[
                ('/model/vehicle_blue/cmd_vel', '/cmd_vel'),
                ('/model/vehicle_blue/odometry', '/odom')
            ],
            output='screen'
        ),

        # ADDED: 4. Localization Node (Kalman Filter)
        Node(
            package='localization_pkg',
            executable='localization_node',
            name='localization',
            parameters=sim_params,
            output='screen'
        ),

        # 5. Speed Control
        Node(
            package='navigation_pkg', 
            executable='speed_control',
            name='speed_ctrl',
            parameters=sim_params,
            remappings=[('/cmd_vel', '/speed_effort')],
            output='screen'
        ),

        # 6. Lateral Control
        Node(
            package='navigation_pkg', 
            executable='lateral_control',
            name='lateral_ctrl',
            parameters=sim_params,
            output='screen'
        ),

        # 7. Planning Node (City Mode)
        Node(
            package='navigation_pkg', 
            executable='planning_node',
            name='planner',
            parameters=[{
                'use_sim_time': True,
                'mode': 'city',
                'cruise_speed': 0.15 
            }],
            output='screen'
        )
    ])
