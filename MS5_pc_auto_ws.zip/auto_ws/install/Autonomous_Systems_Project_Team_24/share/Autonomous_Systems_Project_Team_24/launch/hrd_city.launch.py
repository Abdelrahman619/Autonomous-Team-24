from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    
    common_params = [{'use_sim_time': False}]

    return LaunchDescription([
       
        Node(
            package='navigation_pkg',
            executable='speed_control',
            name='speed_ctrl',
            parameters=common_params,
            
            remappings=[('/cmd_vel', '/speed_effort')],
            output='screen'
        ),

        # 2. Lateral Control (Stanley Controller)
        Node(
            package='navigation_pkg',
            executable='lateral_control',
            name='lateral_ctrl',
            parameters=common_params,
            output='screen',
           
            prefix='xterm -e' 
        ),

        
        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            output='screen',
            parameters=[{
                'mode': 'city',           
                'use_sim_time': False,
                'cruise_speed': 0.1,     
                'slow_speed': 0.05,        
            }]
        )
    ])
