import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
import numpy as np
import random

class LocalizationNode(Node):
    def __init__(self):
        # 1. Node Identity 
        super().__init__('Autonomous_Systems_MS_5_Localization_Team_24')

        # 2. Parameters (Covariance R and Q) 
        self.declare_parameter('process_covariance_Q', 0.01)
        self.declare_parameter('measurement_covariance_R', 0.1)
        self.declare_parameter('noise_std_dev', 0.05) # Standard deviation for noise 

        self.Q = self.get_parameter('process_covariance_Q').value
        self.R = self.get_parameter('measurement_covariance_R').value
        self.noise_std = self.get_parameter('noise_std_dev').value

        # 3. Publishers (Filtered States) 
        self.filtered_odom_pub = self.create_publisher(Odometry, '/filtered_odom', 10)
        self.noisy_odom_pub = self.create_publisher(Odometry, '/noisy_odom', 10)

        # 4. Subscribers 
        self.create_subscription(Odometry, '/odom', self.odom_cb, 10)
        self.create_subscription(Twist, '/cmd_vel', self.cmd_cb, 10)

        # 5. Kalman Filter State Variables 
        self.x_hat = np.array([0.0, 0.0, 0.0]) # [x, y, theta]
        self.P = np.eye(3) * 1.0 
        self.last_time = self.get_clock().now()
        self.v = 0.0
        self.w = 0.0

        self.get_logger().info("Localization Node with Kalman Filter initialized.")

    def cmd_cb(self, msg):
        self.v = msg.linear.x
        self.w = msg.angular.z

    def odom_cb(self, msg):
        # --- 1. Get Actual States ---
        actual_x = msg.pose.pose.position.x
        actual_y = msg.pose.pose.position.y
        # Convert quaternion to yaw
        o = msg.pose.pose.orientation
        actual_yaw = np.arctan2(2.0*(o.w*o.z + o.x*o.y), 1.0-2.0*(o.y*o.y + o.z*o.z))

        # --- 2. Add Gaussian Noise (Simulate Real Sensors) [cite: 19, 32] ---
        noisy_x = actual_x + random.gauss(0, self.noise_std)
        noisy_y = actual_y + random.gauss(0, self.noise_std)
        noisy_yaw = actual_yaw + random.gauss(0, self.noise_std)
        z = np.array([noisy_x, noisy_y, noisy_yaw])

        # Publish Noisy Odom for visualization/comparison [cite: 63]
        noisy_msg = msg
        noisy_msg.pose.pose.position.x = noisy_x
        noisy_msg.pose.pose.position.y = noisy_y
        self.noisy_odom_pub.publish(noisy_msg)

        # --- 3. Kalman Filter Algorithm  ---
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds / 1e9
        self.last_time = now

        # A. Prediction Step
        # Simple kinematic model prediction 
        self.x_hat[0] += self.v * np.cos(self.x_hat[2]) * dt
        self.x_hat[1] += self.v * np.sin(self.x_hat[2]) * dt
        self.x_hat[2] += self.w * dt
        self.P = self.P + np.eye(3) * self.Q

        # B. Correction Step (Update) 
        K = self.P @ np.linalg.inv(self.P + np.eye(3) * self.R)
        self.x_hat = self.x_hat + K @ (z - self.x_hat)
        self.P = (np.eye(3) - K) @ self.P

        # --- 4. Publish Filtered Result [cite: 41] ---
        filtered_msg = Odometry()
        filtered_msg.header = msg.header
        filtered_msg.pose.pose.position.x = self.x_hat[0]
        filtered_msg.pose.pose.position.y = self.x_hat[1]
        
        # Convert yaw back to quaternion for filtered_msg
        filtered_msg.pose.pose.orientation.z = np.sin(self.x_hat[2] / 2.0)
        filtered_msg.pose.pose.orientation.w = np.cos(self.x_hat[2] / 2.0)
        
        self.filtered_odom_pub.publish(filtered_msg)

def main(args=None):
    rclpy.init(args=args)
    node = LocalizationNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Localization Node stopping... Salaam!")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
