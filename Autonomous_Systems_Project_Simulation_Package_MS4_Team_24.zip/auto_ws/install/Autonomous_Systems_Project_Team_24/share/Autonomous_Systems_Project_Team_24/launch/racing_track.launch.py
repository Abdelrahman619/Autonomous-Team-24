import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable
from launch_ros.actions import Node

def generate_launch_description():
    model_path = os.path.expanduser('~/auto_ws/src/locomotion_pkg/models')
    world_path = os.path.expanduser('~/auto_ws/src/Autonomous_Systems_Project_Team_24/Worlds')

    world_file = os.path.join(world_path, 'Racing_Track.world')
    sdf_file = os.path.join(model_path, 'car.sdf')

    return LaunchDescription([
        SetEnvironmentVariable('GZ_SIM_RESOURCE_PATH', model_path),

        ExecuteProcess(cmd=['gz', 'sim', '-r', world_file], output='screen'),

        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=[
                '-file', sdf_file,
                '-name', 'vehicle_blue',
                '-world', 'Racing_Track',
                '-x', '-1.0', '-y', '0.0', '-z', '0.35',
                '-Y', '0.0'
            ],
            output='screen'
        ),

        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=[
                '/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                '/model/vehicle_blue/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
                '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'
            ],
            remappings=[
                ('/model/vehicle_blue/cmd_vel', '/cmd_vel'),
                ('/model/vehicle_blue/odometry', '/odom')
            ],
            output='screen'
        ),

        Node(package='navigation_pkg', executable='speed_control', name='speed_ctrl', output='log'),
        Node(package='navigation_pkg', executable='lateral_control', name='lateral_ctrl',
             output='log', prefix='xterm -e'),

        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            output='screen',
            emulate_tty=True,
            respawn=True,
            respawn_delay=1.0,
            parameters=[{
                'mode': 'racetrack',         # FIX: Tell the node which logic to run
                'use_sim_time': True,        # FIX: Sync with Gazebo clock
                'lane_left': -1.6,
                'lane_right': 1.6,
                'default_lane': -1.6,
                'cruise_speed': 0.6,
                'slow_speed': 0.45,
                'lead_distance': 3.5,
                'post_clearance': 4.0,
                'inflation_ratio': 0.6,
                'obs_x': [4.0, 8.0],
                'obs_y': [1.6, -1.6],
                'obs_size': [1.2, 1.2]
            }]
        ),
    ])
