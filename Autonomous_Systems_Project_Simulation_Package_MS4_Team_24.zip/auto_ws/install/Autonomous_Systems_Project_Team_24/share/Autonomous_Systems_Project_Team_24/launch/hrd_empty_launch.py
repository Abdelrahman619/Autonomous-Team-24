from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 1. Lateral Control (Remapped to listen to the Planner's speed)
        Node(
            package='navigation_pkg',
            executable='lateral_control',
            name='lateral_ctrl',
            output='screen',
            remappings=[('/speed_effort', '/desired_speed')]
        ),

        # 2. Speed Control
        Node(
            package='navigation_pkg',
            executable='speed_control',
            name='speed_ctrl',
            output='screen'
        ),

        # 3. Planning Node (Configured for Max Speed 10m run)
        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            output='screen',
            parameters=[{
                'mode': 'empty_world',
                'use_sim_time': False,
                'cruise_speed': 1.0,  # Max Speed
                'default_lane': 0.0    # Keep Y = 0
            }]
        )
    ])
