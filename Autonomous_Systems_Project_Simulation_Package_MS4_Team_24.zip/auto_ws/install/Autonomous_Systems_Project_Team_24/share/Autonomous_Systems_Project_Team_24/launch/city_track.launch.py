import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable
from launch_ros.actions import Node

def generate_launch_description():
    model_path = os.path.expanduser('~/auto_ws/src/locomotion_pkg/models')
    world_path = os.path.expanduser('~/auto_ws/src/Autonomous_Systems_Project_Team_24/Worlds')

    world_file = os.path.join(world_path, 'City_Track.world')
    sdf_file = os.path.join(model_path, 'car.sdf')

    return LaunchDescription([
        SetEnvironmentVariable(
            'GZ_SIM_RESOURCE_PATH',
            model_path + ':' + os.path.expanduser('~/.gz/models') + ':/usr/share/gz/models'
        ),

        ExecuteProcess(cmd=['gz', 'sim', '-r', world_file], output='screen'),

        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=[
                '-file', sdf_file,
                '-name', 'vehicle_blue',
                '-world', 'City_Track',
                '-x', '-5.5', '-y', '0.0', '-z', '0.35',
                '-Y', '-1.57'
            ],
            output='screen'
        ),

        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=[
                '/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                '/model/vehicle_blue/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
                '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'
            ],
            remappings=[
                ('/model/vehicle_blue/cmd_vel', '/cmd_vel'),
                ('/model/vehicle_blue/odometry', '/odom')
            ],
            output='screen'
        ),

        Node(package='navigation_pkg', executable='speed_control', name='speed_ctrl', output='log'),
        Node(package='navigation_pkg', executable='lateral_control', name='lateral_ctrl',
             output='log', prefix='xterm -e'),

        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            output='screen',
            emulate_tty=True,
            respawn=True,
            respawn_delay=1.0,
            parameters=[{
                'use_sim_time': False,
                'mode': 'city',
                'cruise_speed': 0.4,
                'slow_speed': 0.35,
                'lead_distance': 1.5,
                'post_clearance': 1.5,
                'inflation_ratio': 0.2,
                'wp_x': [-6.25, -6.25, -6.25, -6.25],
                'wp_y': [-3.25, -3.25, -3.25, -3.25]
            }]
        ),
    ])
