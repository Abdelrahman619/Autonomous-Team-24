from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 1. Speed Control (The "Legs")
        # It calculates how much power to give based on desired_speed vs actual_pps
        Node(
            package='navigation_pkg',
            executable='speed_control',
            name='speed_ctrl',
            remappings=[('/cmd_vel', '/speed_effort')] # Redirect output away from cmd_vel
        ),

        # 2. Lateral Control (The "Steering")
        # It takes speed_effort, adds Steering, and sends the FINAL Twist
        Node(
            package='navigation_pkg',
            executable='lateral_control',
            name='lateral_ctrl',
            output='screen'
            # Removed the remapping here so it listens to the REAL speed_effort
        ),

        # 3. Planning Node (The "Brain")
        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            parameters=[{
                'mode': 'city',
                'use_sim_time': False,
                'cruise_speed': 0.4 # Start a bit faster to overcome friction
            }]
        )
    ])
