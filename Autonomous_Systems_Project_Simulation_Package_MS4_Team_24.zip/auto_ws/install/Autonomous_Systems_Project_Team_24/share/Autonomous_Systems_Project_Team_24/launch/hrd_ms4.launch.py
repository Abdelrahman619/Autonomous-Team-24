from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 1. Localization (On the Pi)
        Node(
            package='navigation_pkg',
            executable='bridge_node', # MATCHES YOUR SETUP.PY Entry Point
            name='localization',
            parameters=[{'serial_port': '/dev/ttyACM0', 'baud_rate': 115200}],
            output='screen'
        ),

        # 2. Planning Node (The Brain)
        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            parameters=[{'track_id': 2}],
            output='screen'
        ),

        # 3. Speed Control
        Node(
            package='navigation_pkg',
            executable='speed_control',
            name='speed_ctrl',
            parameters=[{'use_hardware': True}],
            output='screen'
        ),

        # 4. Lateral Control
        Node(
            package='navigation_pkg',
            executable='lateral_control',
            name='lateral_ctrl',
            parameters=[{'use_hardware': True}],
            output='screen'
        ),
    ])
