from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 1. Lateral Control
        Node(
            package='navigation_pkg',
            executable='lateral_control',
            name='lateral_ctrl',
            output='screen',
            remappings=[('/speed_effort', '/desired_speed')]
        ),

        # 2. Speed Control
        Node(
            package='navigation_pkg',
            executable='speed_control',
            name='speed_ctrl',
            output='screen'
        ),

        # 3. Planning Node (Configured for Racetrack)
        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            output='screen',
            parameters=[{
                'mode': 'racetrack',  # Triggers avoidance logic
                'use_sim_time': False,
                'cruise_speed': 0.8,   # Moderate speed for stability
                'lane_left': 1.2,
                'lane_right': -1.2
            }]
        )
    ])
