from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # 1. Speed Control 
        
        Node(
            package='navigation_pkg',
            executable='speed_control',
            name='speed_ctrl',
            remappings=[('/cmd_vel', '/speed_effort')] 
        ),

        # 2. Lateral Control 
        Node(
            package='navigation_pkg',
            executable='lateral_control',
            name='lateral_ctrl',
            output='screen'
            
        ),

        # 3. Planning Node 
        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            parameters=[{
                'mode': 'city',
                'use_sim_time': False,
                'cruise_speed': 0.4 
            }]
        )
    ])
