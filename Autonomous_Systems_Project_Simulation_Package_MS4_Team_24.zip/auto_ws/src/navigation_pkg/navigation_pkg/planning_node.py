import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from std_msgs.msg import Float64
from nav_msgs.msg import Odometry
import math

class PlanningNode(Node):
    def __init__(self):
        super().__init__('planning_node')

        # --- Parameters ---
        self.declare_parameter('mode', 'lane')
        self.declare_parameter('lane_left', -1.25)
        self.declare_parameter('lane_right', 1.25)
        self.declare_parameter('default_lane', -1.25)
        self.declare_parameter('cruise_speed', 10.6)
        self.declare_parameter('slow_speed', 8.45)
        self.declare_parameter('lead_distance', 2.0)
        self.declare_parameter('post_clearance', 2.0)
        self.declare_parameter('inflation_ratio', 0.2)
        self.declare_parameter('obs_x', Parameter.Type.DOUBLE_ARRAY)
        self.declare_parameter('obs_y', Parameter.Type.DOUBLE_ARRAY)
        self.declare_parameter('obs_size', Parameter.Type.DOUBLE_ARRAY)
        self.declare_parameter('wp_x', Parameter.Type.DOUBLE_ARRAY)
        self.declare_parameter('wp_y', Parameter.Type.DOUBLE_ARRAY)

        # Fix for ParameterAlreadyDeclaredException
        if not self.has_parameter('use_sim_time'):
            self.declare_parameter('use_sim_time', True)

        self.mode = str(self.get_parameter('mode').value)
        self.lane_left = float(self.get_parameter('lane_left').value)
        self.lane_right = float(self.get_parameter('lane_right').value)
        self.default_lane = float(self.get_parameter('default_lane').value)
        self.cruise_speed = float(self.get_parameter('cruise_speed').value)
        self.slow_speed = float(self.get_parameter('slow_speed').value)
        self.obs_x = list(self.get_parameter_or('obs_x', Parameter('obs_x', Parameter.Type.DOUBLE_ARRAY, [])).value)
        self.obs_y = list(self.get_parameter_or('obs_y', Parameter('obs_y', Parameter.Type.DOUBLE_ARRAY, [])).value)

        # --- Communication ---
        self.speed_pub = self.create_publisher(Float64, '/desired_speed', 10)
        self.desired_x_pub = self.create_publisher(Float64, '/desired_x', 10)
        self.desired_y_pub = self.create_publisher(Float64, '/desired_y', 10)
        self.heading_pub = self.create_publisher(Float64, '/desired_heading', 10)
        self.create_subscription(Odometry, '/odom', self.odom_cb, 10)

        # --- State Tracking ---
        self.x, self.y, self.yaw = 0.0, 0.0, 0.0
        self.state = 0 
        self.race_state = 0
        self.timer = self.create_timer(0.02, self.loop) # 50Hz for precision

    def odom_cb(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        o = msg.pose.pose.orientation
        self.yaw = math.atan2(2.0 * (o.w * o.z + o.x * o.y), 1.0 - 2.0 * (o.y * o.y + o.z * o.z))

    def loop(self):
        # Default fallback values
        des_x = self.x + 1.0
        des_y = self.default_lane
        des_speed = self.cruise_speed
        heading = 0.0

        if self.mode == 'empty_world':
            if self.x < 10:
                des_x = 12.0
                des_y = 0.0
                des_speed = self.cruise_speed
                heading = 0.0
            else:
                des_x = self.x
                des_y = self.y
                des_speed = 0.0
                heading = self.yaw

        elif self.mode == 'racetrack':
            # --- DYNAMIC TARGET NAVIGATION ---
            if self.race_state == 0:

                des_x = 4.0 
                des_y = 0.0 
                if self.x > 2.0:
                    self.race_state = 1
                    self.get_logger().info("Racetrack: Switching to avoid first obstacle.")

            elif self.race_state == 1:

                des_x = 6.0
                des_y = -0.8 # RIGHT
                if self.x > 6.0:
                    self.race_state = 2
                    self.get_logger().info("Racetrack: Switching to avoid second obstacle.")

            elif self.race_state == 2:
                # Steering back to avoid obstacle 2 (at x=8.0)
                des_x = 10
                des_y = 1.2 # LEFT
                if self.x > 10.0:
                    self.race_state = 3
                    self.get_logger().info("Racetrack: Sequence Complete.")

            elif self.race_state == 3:
                # FIX 
                des_x = self.x
                des_y = 0.0
                des_speed = 6.0
                heading = 0.0
                if self.x > 11.0:
                    self.race_state = 4

            elif self.race_state == 4:
                # STOP logic
                des_x = self.x
                des_y = self.y
                des_speed = 0.0
                self.race_state = 4

            
            # Dynamic Heading: Points the nose AT the target (des_x, des_y)
            if self.race_state < 4:
                heading = math.atan2(des_y - self.y, des_x - self.x)
            else:
                heading = 0.0

        elif self.mode == 'city':
            des_speed = self.cruise_speed
            if self.state == 0:
                des_x = 1.5
                des_y = 0.0
                heading = 0.0
                if self.x > 1.0:
                    self.state = 1
                    self.get_logger().info("State 0 -> 1")
            elif self.state == 1:
                des_x = 3.2
                des_y = 9.0 
                heading = 1.75
                if self.y > 9.0:
                    self.state = 2
                    self.get_logger().info("State 1 -> 2")
            elif self.state == 2:
                des_x = -1.0
                des_y = 10.4
                heading = 2.8
                if self.x < -0.0:
                    self.state = 3
                    self.get_logger().info("State 2 -> 3")
            elif self.state == 3:
                des_x = -2.0
                des_y = 0.0
                heading = -1.45
                if self.y < 0.0:
                    self.state = 0
                    self.get_logger().info("State 3 -> 0")

        # Publish commands
        self.desired_x_pub.publish(Float64(data=float(des_x)))
        self.desired_y_pub.publish(Float64(data=float(des_y)))
        self.speed_pub.publish(Float64(data=float(des_speed)))
        self.heading_pub.publish(Float64(data=float(heading)))

def main():
    rclpy.init()
    node = PlanningNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
