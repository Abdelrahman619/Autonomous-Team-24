import rclpy
from rclpy.node import Node

class HardwareValidation(Node):
    def __init__(self):
        super().__init__('hardware_validation_node')
        self.timer = self.create_timer(1.0, self.timer_callback)
        self.get_logger().info('Team 24: Hardware Validation Node Started')

    def timer_callback(self):
        self.get_logger().info('Status: Raspberry Pi 5 + ROS 2 Jazzy - OK')

def main(args=None):
    rclpy.init(args=args)
    node = HardwareValidation()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
