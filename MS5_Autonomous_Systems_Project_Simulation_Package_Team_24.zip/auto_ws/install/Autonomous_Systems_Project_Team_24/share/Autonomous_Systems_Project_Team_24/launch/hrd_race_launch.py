from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
 
    hw_params = [{'use_sim_time': False}]

    return LaunchDescription([
        # 1. Lateral Control (Stanley)
        Node(
            package='navigation_pkg',
            executable='lateral_control',
            name='lateral_ctrl',
            output='screen',
            parameters=hw_params,
         
        ),

        # 2. Speed Control (PID)
        Node(
            package='navigation_pkg',
            executable='speed_control',
            name='speed_ctrl',
            output='screen',
            parameters=hw_params,
            remappings=[('/cmd_vel', '/speed_effort')] 
        ),

        # 3. Planning Node
        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            output='screen',
            parameters=[{
                'mode': 'racetrack',
                'use_sim_time': False,
                'cruise_speed': 0.1,   
                'lane_left': 0.1875,  
                'lane_right': -0.1875 
            }]
        )
    ])
