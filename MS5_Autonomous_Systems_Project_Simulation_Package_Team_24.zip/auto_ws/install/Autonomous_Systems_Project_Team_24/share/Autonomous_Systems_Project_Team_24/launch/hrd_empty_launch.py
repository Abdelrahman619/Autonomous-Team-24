from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    common_params = [{'use_sim_time': False}]

    return LaunchDescription([
        Node(
            package='navigation_pkg',
            executable='lateral_control',
            name='lateral_ctrl',
            output='screen',
            parameters=common_params,
            prefix='xterm -e'
        ),

        Node(
            package='navigation_pkg',
            executable='speed_control',
            name='speed_ctrl',
            output='screen',
            parameters=common_params
        ),

        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            output='screen',
            parameters=[{
                'mode': 'empty_world',
                'use_sim_time': False,
                'cruise_speed': 0.4,
                'default_lane': 0.0
            }]
        )
    ])
