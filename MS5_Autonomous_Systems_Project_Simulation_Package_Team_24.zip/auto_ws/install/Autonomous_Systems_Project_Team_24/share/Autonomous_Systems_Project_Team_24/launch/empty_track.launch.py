import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable
from launch_ros.actions import Node

def generate_launch_description():
    model_path = os.path.expanduser('~/auto_ws/src/locomotion_pkg/models')
    world_path = os.path.expanduser('~/auto_ws/src/Autonomous_Systems_Project_Team_24/Worlds')

    world_file = os.path.join(world_path, 'Empty_Track.world')
    sdf_file = os.path.join(model_path, 'car.sdf')

    return LaunchDescription([
        SetEnvironmentVariable(
            'GZ_SIM_RESOURCE_PATH',
            model_path + ':' + os.path.expanduser('~/.gz/models') + ':/usr/share/gz/models'
        ),

        # 1. Gazebo Simulation
        ExecuteProcess(cmd=['gz', 'sim', '-r', world_file], output='screen'),

        # 2. Spawn Vehicle
        Node(
            package='ros_gz_sim',
            executable='create',
            arguments=[
                '-file', sdf_file,
                '-name', 'vehicle_blue',
                '-world', 'Empty_Track',
                '-x', '0.0', '-y', '0.0', '-z', '0.35',
                '-Y', '0.0'
            ],
            output='screen'
        ),

        # 3. Parameter Bridge
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=[
                '/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                '/model/vehicle_blue/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
                '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'
            ],
            remappings=[
                ('/model/vehicle_blue/cmd_vel', '/cmd_vel'),
                ('/model/vehicle_blue/odometry', '/odom')
            ],
            output='screen'
        ),

        # 4. Localization Node (Kalman Filter)
        Node(
            package='localization_pkg',
            executable='localization_node',
            name='localization',
            output='screen',
            parameters=[{
                'use_sim_time': False
            }]
        ),

        # 5. Planning Node (Empty World - Straight Line)
        Node(
            package='navigation_pkg',
            executable='planning_node',
            name='planner',
            output='screen',
            parameters=[{
                'use_sim_time': False,
                'mode': 'empty_world',
                'cruise_speed': 1.0,
                'slow_speed': 0.7
            }]
        ),

        # 6. Lateral Control Node
        Node(
            package='navigation_pkg',
            executable='lateral_control',
            name='lateral_ctrl',
            output='screen',
            parameters=[{
                'use_sim_time': False,
                'planning_mode': 'empty_world'
            }]
        ),

        # 7. rqt_graph
        Node(
            package='rqt_graph',
            executable='rqt_graph',
            name='rqt_graph',
            output='screen'
        ),
    ])

