import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
import numpy as np
import math

class KalmanFilterND:
    """Kalman Filter for 2D position and orientation estimation"""
    
    def __init__(self, dt=0.02):
        self.dt = dt
        
        # State: [x, y, theta, vx, vy, vtheta]
        self.x = np.zeros((6, 1))
        
        # State covariance (initial uncertainty)
        self.P = np.eye(6) * 0.5
        
        # Process noise covariance (Q) - noise in the motion model
        q_pos = 0.01      # position noise
        q_ang = 0.005     # angular noise
        q_vel = 0.02      # velocity noise
        
        self.Q = np.diag([q_pos, q_pos, q_ang, q_vel, q_vel, q_vel])
        
        # Measurement noise covariance (R) - noise in sensor readings
        r_pos = 0.05      # GPS/odometry position uncertainty
        r_ang = 0.02      # IMU angular uncertainty
        
        self.R = np.diag([r_pos, r_pos, r_ang])
        
        # State transition matrix (will be updated with dt)
        self.F = np.eye(6)
        self.update_F()
        
        # Measurement matrix (we measure [x, y, theta])
        self.H = np.zeros((3, 6))
        self.H[0, 0] = 1
        self.H[1, 1] = 1
        self.H[2, 2] = 1
    
    def update_F(self):
        """Update state transition matrix with current dt"""
        self.F = np.eye(6)
        self.F[0, 3] = self.dt  # x += vx * dt
        self.F[1, 4] = self.dt  # y += vy * dt
        self.F[2, 5] = self.dt  # theta += vtheta * dt
    
    def predict(self, dt):
        """Prediction step: predict next state"""
        if dt != self.dt:
            self.dt = dt
            self.update_F()
        
        # Predict state
        self.x = self.F @ self.x
        
        # Predict covariance
        self.P = self.F @ self.P @ self.F.T + self.Q
    
    def update(self, z):
        """Update step: correct prediction with measurement"""
        # z is measurement [x, y, theta]
        z = z.reshape((3, 1))
        
        # Innovation (measurement residual)
        y = z - self.H @ self.x
        
        # Normalize angle difference to [-pi, pi]
        y[2, 0] = self._wrap_angle(y[2, 0])
        
        # Innovation covariance
        S = self.H @ self.P @ self.H.T + self.R
        
        # Kalman gain
        K = self.P @ self.H.T @ np.linalg.inv(S)
        
        # Update state
        self.x = self.x + K @ y
        
        # Update covariance
        I = np.eye(6)
        self.P = (I - K @ self.H) @ self.P
    
    @staticmethod
    def _wrap_angle(angle):
        """Wrap angle to [-pi, pi]"""
        while angle > np.pi:
            angle -= 2 * np.pi
        while angle < -np.pi:
            angle += 2 * np.pi
        return angle
    
    def get_state(self):
        """Return current state estimate"""
        return self.x.flatten()


class LocalizationNode(Node):
    def __init__(self):
        super().__init__('localization_node')
        
        # REMOVED: self.declare_parameter('use_sim_time', True)
        
        # Initialize Kalman filter
        self.kf = KalmanFilterND(dt=0.02)
        self.last_time = self.get_clock().now()
        
        # Subscriptions (from Gazebo/Simulation)
        self.create_subscription(Odometry, '/odom', self.odom_callback, 10)
        
        # Publications (filtered odometry)
        self.filtered_odom_pub = self.create_publisher(Odometry, '/filtered_odom', 10)
        self.filtered_x_pub = self.create_publisher(Float64, '/filtered_x', 10)
        self.filtered_y_pub = self.create_publisher(Float64, '/filtered_y', 10)
        self.filtered_theta_pub = self.create_publisher(Float64, '/filtered_theta', 10)
        
        self.get_logger().info("Localization Node started with Kalman Filter")
    
    def odom_callback(self, msg):
        """Process incoming odometry messages"""
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds * 1e-9
        self.last_time = current_time
        
        if dt < 0.001:  # Skip if dt is too small
            return
        
        # Extract position
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        
        # Extract orientation (quaternion to euler)
        o = msg.pose.pose.orientation
        theta = math.atan2(2.0 * (o.w * o.z + o.x * o.y), 
                          1.0 - 2.0 * (o.y * o.y + o.z * o.z))
        
        # Extract velocities (if available)
        vx = msg.twist.twist.linear.x
        vy = msg.twist.twist.linear.y
        vtheta = msg.twist.twist.angular.z
        
        # Create measurement vector
        z = np.array([x, y, theta])
        
        # Kalman Filter: Predict → Update
        self.kf.predict(dt)
        self.kf.update(z)
        
        # Get filtered state
        state = self.kf.get_state()
        filtered_x, filtered_y, filtered_theta = state[0], state[1], state[2]
        
        # Publish filtered odometry
        self._publish_filtered_odom(msg, filtered_x, filtered_y, filtered_theta, vx, vy, vtheta)
        
        # Publish individual filtered states
        self.filtered_x_pub.publish(Float64(data=float(filtered_x)))
        self.filtered_y_pub.publish(Float64(data=float(filtered_y)))
        self.filtered_theta_pub.publish(Float64(data=float(filtered_theta)))
    
    def _publish_filtered_odom(self, original_msg, x, y, theta, vx, vy, vtheta):
        """Publish filtered odometry message"""
        filtered_msg = Odometry()
        filtered_msg.header = original_msg.header
        filtered_msg.child_frame_id = original_msg.child_frame_id
        
        # Set filtered position
        filtered_msg.pose.pose.position.x = float(x)
        filtered_msg.pose.pose.position.y = float(y)
        filtered_msg.pose.pose.position.z = 0.0
        
        # Convert euler to quaternion
        cy = math.cos(theta * 0.5)
        sy = math.sin(theta * 0.5)
        
        filtered_msg.pose.pose.orientation.x = 0.0
        filtered_msg.pose.pose.orientation.y = 0.0
        filtered_msg.pose.pose.orientation.z = sy
        filtered_msg.pose.pose.orientation.w = cy
        
        # Set filtered velocity
        filtered_msg.twist.twist.linear.x = float(vx)
        filtered_msg.twist.twist.linear.y = float(vy)
        filtered_msg.twist.twist.angular.z = float(vtheta)
        
        self.filtered_odom_pub.publish(filtered_msg)


def main(args=None):
    rclpy.init(args=args)
    node = LocalizationNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
