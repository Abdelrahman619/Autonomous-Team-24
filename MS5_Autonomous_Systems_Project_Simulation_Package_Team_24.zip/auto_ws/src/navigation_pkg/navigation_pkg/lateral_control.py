import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
import numpy as np
import time

class LateralControlNode(Node):
    def __init__(self):
        super().__init__('lateral_control')

        if not self.has_parameter('use_sim_time'):
            self.declare_parameter('use_sim_time', False)

        self.k = 0.7  # stanley constant 
        self.max_steer = 1.0
        self.des_x = 0.0
        self.des_y = 0.0
        self.speed_effort = 0.0
        self.des_heading = 0.0

        self.x, self.y, self.yaw = 0.0, 0.0, 0.0
        self.pps = 0.0
        self.acc_y = 0.0  # Slip from Pi
        self.odom_received = False

        # Logging control
        self._last_log = 0.0
        self._log_period = 0.5 

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Subscriptions from planner
        self.create_subscription(Float64, '/desired_x', self.x_cb, 10)
        self.create_subscription(Float64, '/desired_y', self.y_cb, 10)
        self.create_subscription(Float64, '/speed_effort', self.speed_cb, 10)
        self.create_subscription(Float64, '/desired_heading', self.heading_cb, 10)
        
        # Subscriptions from Pi
        self.create_subscription(Odometry, '/odom', self.odom_cb, 10)
        self.create_subscription(Float64, '/actual_pps', self.pps_cb, 10)

        self.timer = self.create_timer(0.01, self.control_loop)  # 100Hz
        self.get_logger().info("Lateral Control Started (Hardware) - Waiting for /odom from Pi...")

    def x_cb(self, msg): 
        self.des_x = float(msg.data)
    
    def y_cb(self, msg): 
        self.des_y = float(msg.data)
    
    def speed_cb(self, msg): 
        self.speed_effort = float(msg.data)
    
    def heading_cb(self, msg): 
        self.des_heading = float(msg.data)
    
    def pps_cb(self, msg):
        self.pps = float(msg.data)

    def odom_cb(self, msg):
        if not self.odom_received:
            self.get_logger().info("✓ ODOM RECEIVED from Pi - Lateral Control Active!")
            self.odom_received = True
        
        # Position from Pi
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        
        # Orientation from Pi
        o = msg.pose.pose.orientation
        self.yaw = np.arctan2(2.0*(o.w*o.z + o.x*o.y), 1.0-2.0*(o.y*o.y + o.z*o.z))
        
        # Slip from Pi covariance[14] (z rotation variance)
        self.acc_y = msg.pose.covariance[14]

    @staticmethod
    def wrap_pi(a): 
        return (a + np.pi) % (2.0 * np.pi) - np.pi

    def control_loop(self):
        # FIXED: Deadzone to prevent steering at zero speed
        if abs(self.speed_effort) < 0.05:
            cmd = Twist()
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            self.cmd_pub.publish(cmd)
            return

        v = max(abs(self.speed_effort), 0.1)
        
        # 1. Heading Error 
        psi_e = self.wrap_pi(self.des_heading - self.yaw)
        
        # 2. Cross-track Error
        dx = self.x - self.des_x
        dy = self.y - self.des_y
        e = -dx * np.sin(self.des_heading) + dy * np.cos(self.des_heading)

        # 3. Stanley Control Law
        delta = psi_e + np.arctan2(self.k * -e, v)
        delta = float(np.clip(delta, -self.max_steer, self.max_steer))

        cmd = Twist()
        cmd.linear.x = float(self.speed_effort)
        cmd.angular.z = delta
        self.cmd_pub.publish(cmd)

        # Print logic
        now = time.time()
        if (now - self._last_log) > self._log_period:
            self.get_logger().info(
                f"\n--- Navigation Update (Hardware) ---\n"
                f"CURRENT (Goal):   X: {self.x:5.2f} | Y: {self.y:5.2f} | Yaw: {self.yaw:5.2f}\n"
                f"DESIRED (Target): X: {self.des_x:5.2f} | Y: {self.des_y:5.2f} | Head: {self.des_heading:5.2f}\n"
                f"ERRORS:            Cross-Track: {e:5.2f} | Heading: {psi_e:5.2f}\n"
                f"CONTROL:           Steer: {delta:5.2f} | Speed: {self.speed_effort:5.2f}\n"
                f"FROM Pi:           PPS: {self.pps:5.0f} | Slip: {self.acc_y:5.4f}\n"
                f"-------------------------"
            )
            self._last_log = now

def main():
    rclpy.init()
    node = LateralControlNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
