import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Bool
import sys, select, termios, tty, math, traceback

class TeleopNode(Node):
    def __init__(self):
        super().__init__('teleop_node')
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.olr_status_pub = self.create_publisher(Bool, '/olr_active', 10)
        
        # THE FIX: Subscribing directly to /odom which starts at (0, 0)
        self.pose_sub = self.create_subscription(Odometry, '/odom', self.odom_cb, 10)
        
        self.v, self.phi = 0.0, 0.0
        self.manual_mode = True
        self.state_str = "Waiting for Odom..."
        self.settings = termios.tcgetattr(sys.stdin)

    def odom_cb(self, msg):
        pos = msg.pose.pose.position
        ori = msg.pose.pose.orientation
        yaw = math.atan2(2.0*(ori.w*ori.z + ori.x*ori.y), 1.0 - 2.0*(ori.y**2 + ori.z**2))
        self.state_str = f"X:{pos.x:.2f} Y:{pos.y:.2f} Yaw:{math.degrees(yaw):.1f}°"

    def get_key(self):
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
        key = sys.stdin.read(1) if rlist else ''
        if key == '\x1b': key += sys.stdin.read(2)
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    def run(self):
        try:
            while rclpy.ok():
                key = self.get_key()
                if key.lower() == 'm':
                    self.manual_mode = not self.manual_mode
                    msg = Bool(); msg.data = not self.manual_mode
                    self.olr_status_pub.publish(msg)
                elif key == ' ':
                    self.manual_mode = True; self.v, self.phi = 0.0, 0.0
                    self.olr_status_pub.publish(Bool(data=False))
                    self.publisher.publish(Twist())
                elif key == '\x1b[A': self.v = min(self.v + 0.1, 2.0)   # Max Speed 2.0
                elif key == '\x1b[B': self.v = max(self.v - 0.1, -2.0)  # Min Speed -2.0
                elif key == '\x1b[C': self.phi = max(self.phi - 0.1, -1.0) # Max Steering 1.0
                elif key == '\x1b[D': self.phi = min(self.phi + 0.1, 1.0)  # Min Steering -1.0
                elif key == '\x03': break

                if self.manual_mode:
                    cmd = Twist()
                    cmd.linear.x, cmd.angular.z = float(self.v), float(self.phi)
                    self.publisher.publish(cmd)
                
                label = "MANUAL" if self.manual_mode else "OLR ACTIVE"
                sys.stdout.write(f"\r [{label}] {self.state_str} | V:{self.v:.1f} Phi:{self.phi:.1f}  ")
                sys.stdout.flush()
                rclpy.spin_once(self, timeout_sec=0.01)
        finally:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)

def main(args=None):
    rclpy.init(args=args)
    node = TeleopNode()
    try:
        node.run()
    except Exception as e:
        print(f"\n\n[FATAL ERROR] The teleop node crashed:")
        traceback.print_exc()
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
