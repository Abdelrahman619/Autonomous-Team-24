import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
from std_msgs.msg import Float64MultiArray
import time


class SpeedControlNode(Node):
    def __init__(self):
        super().__init__('speed_control')

        self.declare_parameter('use_hardware', False)
        self.use_hardware = bool(self.get_parameter('use_hardware').value)

        # v(m/s) = pps / K_MAP
        self.K_MAP = 10252.0
        self.kp = 1.0

        self.current_v_actual = 0.0
        self.current_pps = 0.0
        self.last_hw_time = 0.0
        self.hw_timeout = 0.25

        self.desired_speed = 0.0

        # pubs
        self.effort_pub = self.create_publisher(Float64, '/speed_effort', 10)
        self.err_pub = self.create_publisher(Float64, '/speed_error', 10)

        # subs
        self.create_subscription(Float64, '/desired_speed', self.desired_speed_cb, 10)

        if self.use_hardware:
            self.create_subscription(Float64MultiArray, '/hardware/vehicle_states', self.hw_state_cb, 10)
        else:
            self.create_subscription(Odometry, '/odom', self.odom_cb, 10)

        self.timer = self.create_timer(0.05, self.control_loop)

    def desired_speed_cb(self, msg):
        self.desired_speed = float(msg.data)

    def odom_cb(self, msg):
        self.current_v_actual = float(msg.twist.twist.linear.x)

    def hw_state_cb(self, msg):
        # msg.data = [pps, yaw, x, y]
        if len(msg.data) < 4:
            return
        self.current_pps = float(msg.data[0])
        self.current_v_actual = self.current_pps / self.K_MAP
        self.last_hw_time = time.time()

    def control_loop(self):
        # Hardware stale protection
        if self.use_hardware and (time.time() - self.last_hw_time) > self.hw_timeout:
            self.current_v_actual = 0.0

        # --- FIX: Stop Oscillation Deadzone ---
        # If the planner wants to stop, we force effort to 0.0 immediately
        if abs(self.desired_speed) < 0.01:
            self.err_pub.publish(Float64(data=0.0))
            self.effort_pub.publish(Float64(data=0.0))
            return

        error = self.desired_speed - self.current_v_actual

        e = Float64()
        e.data = float(error)
        self.err_pub.publish(e)

        effort = Float64()
        effort.data = float(self.desired_speed + self.kp * error)
        self.effort_pub.publish(effort)


def main():
    rclpy.init()
    rclpy.spin(SpeedControlNode())
    rclpy.shutdown()


if __name__ == '__main__':
    main()
