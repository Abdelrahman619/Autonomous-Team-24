from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'navigation_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='abdo',
    maintainer_email='abdo@todo.todo',
    description='Autonomous Robot',
    license='Apache-2.0',
    tests_require=['pytest'],
 entry_points={
        'console_scripts': [
            'teleop = navigation_pkg.teleop_node:main',
            'planning_node = navigation_pkg.planning_node:main',
            'bridge_node = navigation_pkg.serial_bridge_node:main',
            'olr = navigation_pkg.olr_node:main',
            'lateral_control = navigation_pkg.lateral_control:main',
            'speed_control = navigation_pkg.speed_control:main',
        ],
    },
)
