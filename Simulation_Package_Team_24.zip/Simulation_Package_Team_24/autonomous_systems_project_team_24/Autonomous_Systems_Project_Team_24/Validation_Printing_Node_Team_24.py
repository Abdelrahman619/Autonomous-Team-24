import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
import sys, select, termios, tty
import time

class ManualValidationNode(Node):
    def __init__(self):
        super().__init__('Validation_Printing_Node_Team_24')
        self.pub = self.create_publisher(Twist, '/model/vehicle_blue/cmd_vel', 10)
        self.sub = self.create_subscription(Odometry, '/model/vehicle_blue/odometry', self.location_callback, 10)
        
        # Initial State
        self.current_pos = "0.00, 0.00"
        self.data_received = False 
        
        self.create_timer(1.0, self.slow_print)
        self.get_logger().info("Node Reset & Ready - Team 24")

    def location_callback(self, msg):
        p = msg.pose.pose.position
        self.current_pos = f"x={p.x:.2f}, y={p.y:.2f}"
        self.data_received = True

    def slow_print(self):
        if self.data_received:
            self.get_logger().info(f"Live Position -> {self.current_pos}")
        else:
            self.get_logger().info("Waiting for fresh simulation data...")

def get_key(settings):
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    key = sys.stdin.read(1) if rlist else ''
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

def main():
    settings = termios.tcgetattr(sys.stdin)
    rclpy.init()
    node = ManualValidationNode()

    try:
        while rclpy.ok():
            key = get_key(settings)
            if key == '\x03': break
                
            drive_msg = Twist()
            if key == 'w': drive_msg.linear.x = 0.7
            elif key == 'a': drive_msg.linear.x = 0.5; drive_msg.angular.z = 0.5
            elif key == 'd': drive_msg.linear.x = 0.5; drive_msg.angular.z = -0.5
            elif key == 'x': drive_msg.linear.x = -0.5
            elif key == 's': pass
            
            if key in ['w', 'a', 'd', 'x', 's']:
                node.pub.publish(drive_msg)
            
            rclpy.spin_once(node, timeout_sec=0.05)
            
    except Exception as e:
        print(e)
    finally:
        node.pub.publish(Twist())
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
