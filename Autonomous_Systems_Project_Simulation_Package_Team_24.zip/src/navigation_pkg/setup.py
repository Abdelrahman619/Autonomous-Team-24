from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'navigation_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # EL LINE DA MOHEM GEDAN:
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='abdo',
    maintainer_email='abdo@todo.todo',
    description='Navigation and Teleop for Autonomous Robot',
    license='Apache-2.0',
    tests_require=['pytest'],
 entry_points={
        'console_scripts': [
            'teleop = navigation_pkg.teleop_node:main',
            'planner = navigation_pkg.planner_node:main',
            'controller = navigation_pkg.controller_node:main',
            'bridge_node = navigation_pkg.serial_bridge_node:main', # Matched to your alias
            'olr = navigation_pkg.olr_node:main',
        ],
    },
)
