import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable
from launch_ros.actions import Node

def generate_launch_description():
    model_path = os.path.expanduser('~/auto_ws/src/locomotion_pkg/models')
    world_file_path = os.path.join(model_path, 'my_car.sdf')
    
    set_gz_resource_path = SetEnvironmentVariable(
        name='GZ_SIM_RESOURCE_PATH',
        value=model_path
    )

    gazebo_sim = ExecuteProcess(
        cmd=['gz', 'sim', '-r', world_file_path],
        output='screen'
    )

    bridge_node = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            '/model/vehicle_blue/pose@geometry_msgs/msg/Pose@gz.msgs.Pose',
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'
        ],
        output='screen'
    )

    cmd_remap = [('/cmd_vel', '/model/vehicle_blue/cmd_vel')]

    controller_node = Node(
        package='navigation_pkg',
        executable='controller',
        output='screen',
        parameters=[{'goal_x': 15.0, 'goal_y': 4.0, 'use_sim_time': True}],
        remappings=cmd_remap
    )

    teleop_node = Node(
        package='navigation_pkg',
        executable='teleop',
        prefix="xterm -e",
        output='screen',
        parameters=[{'use_sim_time': True}],
        remappings=cmd_remap
    )

    kinematics_node = Node(
        package='locomotion_pkg',
        executable='kinematics',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    return LaunchDescription([
        set_gz_resource_path,
        gazebo_sim,
        bridge_node,
        controller_node,
        teleop_node,
        kinematics_node
    ])
