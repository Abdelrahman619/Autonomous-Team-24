import rclpy
from rclpy.node import Node

class PlannerNode(Node):
    def __init__(self):
        super().__init__('planner_node')
        # Declare Desired Parameters
        self.declare_parameter('desired_speed', 1.5)
        self.declare_parameter('desired_lane', 2)

        self.target_v = self.get_parameter('desired_speed').value
        self.target_lane = self.get_parameter('desired_lane').value

        self.get_logger().info(f'Target: Speed={self.target_v}, Lane={self.target_lane}')

def main(args=None):
    rclpy.init(args=args)
    node = PlannerNode()
    rclpy.spin(node)
    rclpy.shutdown()
