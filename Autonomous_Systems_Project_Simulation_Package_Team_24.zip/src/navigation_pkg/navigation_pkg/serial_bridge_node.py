import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial

class SerialBridgeNode(Node):
    def __init__(self):
        super().__init__('serial_bridge_node')
        
        # Connect to Arduino via USB
        try:
            self.ser = serial.Serial('/dev/ttyACM0', 115200, timeout=0.1)
            self.get_logger().info('Connected to Arduino via USB!')
        except Exception as e:
            self.get_logger().error(f'Cannot find Arduino. Is it plugged in? Error: {e}')
            self.ser = None

        self.subscription = self.create_subscription(Twist, '/cmd_vel', self.cmd_callback, 10)

    def cmd_callback(self, msg):
        if self.ser and self.ser.is_open:
            v = msg.linear.x
            phi = msg.angular.z
            
            # Send exactly like: "1.50,0.50\n"
            command = f"{v:.2f},{phi:.2f}\n"
            self.ser.write(command.encode('utf-8'))

def main(args=None):
    rclpy.init(args=args)
    node = SerialBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node.ser:
            node.ser.write("0.00,0.00\n".encode('utf-8'))
            node.ser.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
