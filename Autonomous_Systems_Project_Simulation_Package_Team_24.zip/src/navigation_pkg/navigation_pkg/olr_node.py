import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Pose
from std_msgs.msg import Bool
import math
import sys

class OLRNode(Node):
    def __init__(self):
        super().__init__('olr_node')
        self.declare_parameter('desired_speed', 1.0)
        self.declare_parameter('steering', 0.0)

        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.status_sub = self.create_subscription(Bool, '/olr_active', self.status_cb, 10)
        self.pose_sub = self.create_subscription(Pose, '/model/vehicle_blue/pose', self.state_cb, 10)

        # FIXED: Set to True so it moves on launch
        self.active = True 
        self.timer = self.create_timer(0.1, self.timer_cb)
        self.get_logger().info("OLR Node LIVE and Active.")

    def status_cb(self, msg):
        self.active = msg.data

    def state_cb(self, msg):
        if self.active:
            pos = msg.position
            ori = msg.orientation
            yaw = math.atan2(2.0*(ori.w*ori.z + ori.x*ori.y), 1.0 - 2.0*(ori.y**2 + ori.z**2))
            sys.stdout.write(f"\r[OLR] X:{pos.x:.1f} Y:{pos.y:.1f} Yaw:{math.degrees(yaw):.1f}°   ")
            sys.stdout.flush()

    def timer_cb(self):
        if self.active:
            msg = Twist()
            msg.linear.x = float(self.get_parameter('desired_speed').value)
            msg.angular.z = float(self.get_parameter('steering').value)
            self.publisher.publish(msg)

def main(args=None):
    rclpy.init(args=args); node = OLRNode()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally: node.destroy_node(); rclpy.shutdown()
