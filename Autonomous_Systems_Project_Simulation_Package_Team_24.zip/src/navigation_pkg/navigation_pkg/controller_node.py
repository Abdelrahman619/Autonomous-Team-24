import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Pose2D
from std_msgs.msg import Bool
import numpy as np

class ControllerNode(Node):
    def __init__(self):
        super().__init__('controller_node')
        self.declare_parameter('goal_x', 15.0)
        self.declare_parameter('goal_y', 4.0)
        self.declare_parameter('goal_theta', 0.0) 
        
        self.manual_active = False 
        self.goal_reached = False 
        
        # MODIFIED GAINS: Drive slower, steer harder to fix the 50.2 degree error
        self.k_rho = 1.5    
        self.k_alpha = 3.5  
        self.k_beta = -2.0  
        self.L = 1.0 
        
        self.create_subscription(Pose2D, '/current_pose', self.control_callback, 10)
        self.create_subscription(Bool, '/manual_mode', self.mode_callback, 10)
        self.vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)

    def mode_callback(self, msg):
        self.manual_active = msg.data
        self.goal_reached = False 

    def control_callback(self, pose):
        if self.manual_active or self.goal_reached:
            return 

        goal_x = self.get_parameter('goal_x').value
        goal_y = self.get_parameter('goal_y').value
        goal_theta_deg = self.get_parameter('goal_theta').value
        thetaG = np.radians(goal_theta_deg)

        xc = pose.x
        yc = pose.y
        thetac = np.radians(pose.theta)

        rho = np.sqrt((goal_x - xc)**2 + (goal_y - yc)**2)
        
        alpha_raw = np.arctan2(goal_y - yc, goal_x - xc)
        alpha = alpha_raw - thetac
        alpha = (alpha + np.pi) % (2 * np.pi) - np.pi 
        
        beta = -alpha - thetac + thetaG
        beta = (beta + np.pi) % (2 * np.pi) - np.pi 

        cmd = Twist()
        
        # Tighter stopping radius
        if rho > 0.15: 
            if abs(np.degrees(alpha)) <= 85:
                v = self.k_rho * rho
                direction = 1.0
            else:
                v = -self.k_rho * rho
                direction = -1.0
            
            omega_desired = self.k_alpha * alpha + self.k_beta * beta
            
            safe_v = v if abs(v) > 0.01 else 0.01 * direction
            phi = np.arctan((omega_desired * self.L) / safe_v)

            if direction < 0:
                phi = -phi

            v = np.clip(v, -1.0, 1.0) # Lowered max speed for better angle correction
            phi = np.clip(phi, -0.5, 0.5) 

            cmd.linear.x = float(v)
            cmd.angular.z = float(phi) 
            
        else:
            self.get_logger().info('TARGET REACHED! Stopping.')
            self.goal_reached = True
            cmd.linear.x = 0.0
            cmd.angular.z = 0.0
            
        self.vel_pub.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = ControllerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
