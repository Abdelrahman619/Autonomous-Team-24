import rclpy
from rclpy.node import Node
import numpy as np

class DynamicsNode(Node):
    def __init__(self):
        super().__init__('dynamics_node')
        
        # Physical Parameters (From Dr. Omar's Dynamics script)
        self.r = 0.1      # Wheel radius
        self.l = 0.25     # Wheelbase
        self.m = 1.0      # Mass
        self.j = 0.2      # Inertia
        
        # Initial States
        self.x = 2.5
        self.y = 5.0
        self.theta = 0.0
        self.v = -0.4             # Initial linear velocity
        self.omega = -np.pi/20.0  # Initial angular velocity
        
        # Inputs (Torques)
        self.torque_r = 0.001
        self.torque_l = 0.0006
        
        # Timer (Ts = 0.001s as per script)
        self.ts = 0.001
        self.timer = self.create_timer(self.ts, self.timer_callback)
        
        self.get_logger().info('Dynamics Node (Physics Engine) has started!')

    def timer_callback(self):
        # 1. Calculate Accelerations (moves)
        v_dot = (1.0 / (self.m * self.r)) * (self.torque_r + self.torque_l)
        omega_dot = (self.l / (2.0 * self.r * self.j)) * (self.torque_r - self.torque_l)
        
        # 2. Integrate to get Velocities
        self.v += v_dot * self.ts
        self.omega += omega_dot * self.ts
        
        # 3. Integrate to get Pose (The "Where" it goes)
        self.theta += self.omega * self.ts
        
        # Using the current theta for the direction of movement
        x_dot = self.v * np.cos(self.theta)
        y_dot = self.v * np.sin(self.theta)
        
        self.x += x_dot * self.ts
        self.y += y_dot * self.ts
        
        # 4. Log the progress
        self.get_logger().info(f'Dyn Pose: x={self.x:.2f}, y={self.y:.2f}, v={self.v:.2f}')

def main(args=None):
    rclpy.init(args=args)
    node = DynamicsNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
