import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Pose, Pose2D
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import numpy as np

class KinematicsNode(Node):
    def __init__(self):
        super().__init__('kinematics_node')
        
        # Gazebo often requires a specific QoS to deliver messages
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        self.subscription = self.create_subscription(
            Pose, 
            '/model/vehicle_blue/pose', 
            self.pose_callback, 
            qos_profile)
            
        self.pose_publisher = self.create_publisher(Pose2D, '/current_pose', 10)
        
        self.log_counter = 0
        self.get_logger().info('Kinematics Node Online (QoS Adjusted).')

    def pose_callback(self, msg):
        # 1. Position
        x = msg.position.x
        y = msg.position.y
        
        # 2. Orientation (Quaternion to Euler Yaw)
        q = msg.orientation
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        theta_rad = np.arctan2(siny_cosp, cosy_cosp)
        theta_deg = np.degrees(theta_rad)

        # 3. Publish to Controller
        pose_msg = Pose2D()
        pose_msg.x = x
        pose_msg.y = y
        pose_msg.theta = theta_deg
        self.pose_publisher.publish(pose_msg)

        # 4. Log status at 10Hz
        self.log_counter += 1
        if self.log_counter >= 10:
            self.get_logger().info(f'FEEDBACK: x={x:.2f}, y={y:.2f}, th={theta_deg:.1f}')
            self.log_counter = 0

def main(args=None):
    rclpy.init(args=args)
    node = KinematicsNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
