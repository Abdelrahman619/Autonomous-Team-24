import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    model_path = os.path.expanduser('~/auto_ws/src/locomotion_pkg/models')
    world_file = os.path.join(model_path, 'my_car.sdf')
    set_gz_path = SetEnvironmentVariable('GZ_SIM_RESOURCE_PATH', model_path)
    cmd_remap = [('/cmd_vel', '/model/vehicle_blue/cmd_vel')]

    return LaunchDescription([
        set_gz_path,
        DeclareLaunchArgument('desired_speed', default_value='1.2'),
        DeclareLaunchArgument('steering',      default_value='0.0'),
        ExecuteProcess(cmd=['gz', 'sim', '-r', world_file], output='screen'),
        Node(
            package='ros_gz_bridge', executable='parameter_bridge',
            arguments=['/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                       '/model/vehicle_blue/pose@geometry_msgs/msg/Pose@gz.msgs.Pose'],
            output='screen'
        ),
        Node(
            package='navigation_pkg', executable='olr',
            prefix='xterm -e', # SEPARATE SCREEN
            parameters=[{'desired_speed': LaunchConfiguration('desired_speed'), 'steering': LaunchConfiguration('steering')}],
            remappings=cmd_remap, output='screen'
        ),
        Node(package='rqt_graph', executable='rqt_graph', name='rqt_graph')
    ])
