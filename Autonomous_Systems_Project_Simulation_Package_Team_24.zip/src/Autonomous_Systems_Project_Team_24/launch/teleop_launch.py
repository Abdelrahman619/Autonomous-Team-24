import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable
from launch_ros.actions import Node

def generate_launch_description():
    model_path = os.path.expanduser('~/auto_ws/src/locomotion_pkg/models')
    world_file = os.path.join(model_path, 'my_car.sdf')
    set_gz_path = SetEnvironmentVariable('GZ_SIM_RESOURCE_PATH', model_path)
    cmd_remap = [('/cmd_vel', '/model/vehicle_blue/cmd_vel')]

    return LaunchDescription([
        set_gz_path,
        ExecuteProcess(cmd=['gz', 'sim', '-r', world_file], output='screen'),
        Node(
            package='ros_gz_bridge', executable='parameter_bridge',
            arguments=['/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                       '/model/vehicle_blue/pose@geometry_msgs/msg/Pose@gz.msgs.Pose'],
            output='screen'
        ),
        Node(
            package='navigation_pkg', executable='teleop',
            prefix='xterm -e', # SEPARATE SCREEN
            remappings=cmd_remap, output='screen'
        ),
        Node(package='rqt_graph', executable='rqt_graph', name='rqt_graph')
    ])
