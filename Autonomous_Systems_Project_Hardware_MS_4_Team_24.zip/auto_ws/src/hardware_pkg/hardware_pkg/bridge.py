import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
import serial
import math

class UnifiedBridgeNode(Node):
    def __init__(self):
        super().__init__('bridge_node')
        self.ser = None
        for port in ('/dev/ttyUSB0', '/dev/ttyACM0'):
            try:
                self.ser = serial.Serial(port, 115200, timeout=0.05)
                self.get_logger().info(f"Connected to {port}")
                break
            except:
                continue
        
        if not self.ser:
            raise RuntimeError("Arduino not found")

        # Hands & Eyes
        self.create_subscription(Twist, '/cmd_vel', self.cmd_cb, 10)
        self.odom_pub = self.create_publisher(Odometry, '/odom', 10)
        self.create_timer(0.02, self.read_cb)

    def cmd_cb(self, msg):
        data = f"{msg.linear.x:.2f},{msg.angular.z:.2f}\n"
        self.ser.write(data.encode('utf-8'))

    def read_cb(self):
        if self.ser.in_waiting > 0:
            try:
                line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                if line.startswith("STATE:"):
                    p = line.replace("STATE:", "").split(",")
                    if len(p) == 4:
                        # Yaw conversion for the PC Brain
                        rad = math.radians(float(p[1]))
                        msg = Odometry()
                        msg.pose.pose.position.x = float(p[2])
                        msg.pose.pose.position.y = float(p[3])
                        msg.pose.pose.orientation.z = math.sin(rad/2)
                        msg.pose.pose.orientation.w = math.cos(rad/2)
                        self.odom_pub.publish(msg)
            except:
                pass

def main():
    rclpy.init()
    rclpy.spin(UnifiedBridgeNode())
    rclpy.shutdown()

if __name__ == '__main__':
    main()
