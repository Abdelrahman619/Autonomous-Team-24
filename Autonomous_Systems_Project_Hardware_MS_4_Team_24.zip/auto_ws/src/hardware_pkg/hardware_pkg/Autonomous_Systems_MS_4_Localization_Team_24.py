import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
import serial
import math

class LocalizationNode(Node):
    def __init__(self):
        super().__init__('localization_node')
        self.ser = None
        for port in ('/dev/ttyUSB0', '/dev/ttyACM0'):
            try:
                self.ser = serial.Serial(port, 115200, timeout=0.05)
                self.get_logger().info(f"Localization connected to {port}")
                break
            except:
                continue
        
        if not self.ser:
            raise RuntimeError("Arduino not found for Localization")

        self.odom_pub = self.create_publisher(Odometry, '/odom', 10)
        self.pps_pub = self.create_publisher(Float64, '/actual_pps', 10)
        self.create_timer(0.02, self.timer_cb)

    def timer_cb(self):
        if self.ser.in_waiting > 0:
            try:
                line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                if line.startswith("STATE:"):
                    parts = line.replace("STATE:", "").split(",")
                    if len(parts) == 4:
                        pps, yaw_deg, x, y = map(float, parts)
                        
                        # Yaw to Quaternion for PC Lateral Control
                        rad = math.radians(yaw_deg)
                        qz = math.sin(rad / 2.0)
                        qw = math.cos(rad / 2.0)

                        msg = Odometry()
                        msg.header.stamp = self.get_clock().now().to_msg()
                        msg.header.frame_id = "odom"
                        msg.pose.pose.position.x = x
                        msg.pose.pose.position.y = y
                        msg.pose.pose.orientation.z = qz
                        msg.pose.pose.orientation.w = qw
                        
                        self.odom_pub.publish(msg)
                        self.pps_pub.publish(Float64(data=pps))
            except:
                pass

def main():
    rclpy.init()
    node = LocalizationNode()
    try:
        rclpy.spin(node)
    finally:
        if node.ser: node.ser.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
