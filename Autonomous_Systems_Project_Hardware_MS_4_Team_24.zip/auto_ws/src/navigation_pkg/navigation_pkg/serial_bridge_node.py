import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64, Bool # Added Bool
import serial

class SerialBridgeNode(Node):
    def __init__(self):
        super().__init__('serial_bridge_node')

        # Publisher for the "Auto-Detection" status
        self.status_pub = self.create_publisher(Bool, '/hardware_status', 10)
        self.pps_pub = self.create_publisher(Float64, '/actual_pps', 10)
        
        self.ser = None
        self.connect_serial()

        self.subscription = self.create_subscription(
            Twist, '/model/vehicle_blue/cmd_vel', self.cmd_callback, 10)

        # Timer to check for feedback AND publish heartbeat
        self.timer = self.create_timer(0.05, self.bridge_tick) 

    def connect_serial(self):
        ports = ['/dev/ttyACM0', '/dev/ttyUSB0']
        for port in ports:
            try:
                self.ser = serial.Serial(port, 115200, timeout=0.1)
                self.get_logger().info(f'Hardware Found on {port}!')
                return
            except Exception:
                continue
        self.get_logger().warn('No Arduino found. Falling back to Simulation mode.')

    def bridge_tick(self):
        # 1. Publish Heartbeat
        status_msg = Bool()
        status_msg.data = self.ser is not None and self.ser.is_open
        self.status_pub.publish(status_msg)

        # 2. Read Feedback if hardware is active
        if status_msg.data and self.ser.in_waiting > 0:
            try:
                line = self.ser.readline().decode('utf-8').rstrip()
                if "Actual:" in line:
                    actual_pps = float(line.split("Actual:")[1])
                    msg = Float64()
                    msg.data = actual_pps
                    self.pps_pub.publish(msg)
            except Exception as e:
                self.get_logger().warn(f"Serial Read Error: {e}")

    def cmd_callback(self, msg):
        if self.ser and self.ser.is_open:
            command = f"{msg.linear.x:.2f},{msg.angular.z:.2f}\n"
            self.ser.write(command.encode('utf-8'))

def main(args=None):
    rclpy.init(args=args)
    node = SerialBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node.ser:
            node.ser.write("0.00,0.00\n".encode('utf-8'))
            node.ser.close()
        node.destroy_node()
        rclpy.shutdown()
