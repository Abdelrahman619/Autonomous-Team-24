import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable
from launch_ros.actions import Node

def generate_launch_description():
    model_path = os.path.expanduser('~/auto_ws/src/locomotion_pkg/models')
    world_file = os.path.join(model_path, 'my_car.sdf')

    return LaunchDescription([
        SetEnvironmentVariable('GZ_SIM_RESOURCE_PATH', model_path),

        ExecuteProcess(cmd=['gz', 'sim', '-r', world_file], output='screen'),

        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=[
                '/model/vehicle_blue/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
                '/model/vehicle_blue/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry',
                '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'
            ],
            output='screen'
        ),

        Node(
            package='navigation_pkg',
            executable='speed_control',
            parameters=[{
                'desired_speed': 0.4,
                'use_hardware': False
            }],
            output='screen'
        ),

        Node(
            package='navigation_pkg',
            executable='lateral_control',
            prefix='xterm -e',
            parameters=[{
                'goal_x': 4.0,
                'goal_y': 1.0,
                'goal_theta': -30.0,
                'use_hardware': False
            }],
            output='screen'
        ),

        Node(
            package='rqt_graph',
            executable='rqt_graph',
            output='screen'
        ),
    ])
