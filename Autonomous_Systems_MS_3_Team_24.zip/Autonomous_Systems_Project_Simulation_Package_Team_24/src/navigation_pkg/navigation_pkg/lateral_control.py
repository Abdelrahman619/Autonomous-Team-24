import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64
import numpy as np
import sys
import select
import termios
import tty

class LateralControlNode(Node):
    def __init__(self):
        super().__init__('lateral_control')

        self.declare_parameter('goal_x', 4.0)
        self.declare_parameter('goal_y', 1.0)
        self.declare_parameter('goal_theta', -30.0)

        self.current_speed_effort = 0.0
        self.goal_reached = False
        self.settings = termios.tcgetattr(sys.stdin)

        self.k_rho = 0.45
        self.k_alpha = 2.2
        self.k_beta = -0.8

        self.xy_tol = 0.15 
        self.theta_tol = np.radians(3.0) # 3 degrees tolerance ONLY

        self.v_min = 0.18
        self.v_max = 0.35
        self.max_omega = 0.8

        self.cmd_pub = self.create_publisher(Twist, '/model/vehicle_blue/cmd_vel', 10)
        self.create_subscription(Float64, '/speed_effort', self.speed_effort_cb, 10)
        self.create_subscription(Odometry, '/model/vehicle_blue/odometry', self.odom_cb, 10)
        self.create_timer(0.05, self.check_keyboard)

    @staticmethod
    def wrap_pi(a):
        return (a + np.pi) % (2.0 * np.pi) - np.pi

    def speed_effort_cb(self, msg):
        self.current_speed_effort = msg.data

    def get_key(self):
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.01)
        key = sys.stdin.read(1) if rlist else None
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    def check_keyboard(self):
        if self.get_key() == ' ':
            self.goal_reached = True
            self.cmd_pub.publish(Twist())

    def odom_cb(self, msg):
        pos = msg.pose.pose.position
        ori = msg.pose.pose.orientation
        yaw = np.arctan2(2.0 * (ori.w * ori.z + ori.x * ori.y), 1.0 - 2.0 * (ori.y**2 + ori.z**2))
        yaw_deg = float(np.degrees(yaw))

        gx = float(self.get_parameter('goal_x').value)
        gy = float(self.get_parameter('goal_y').value)
        gth_deg = float(self.get_parameter('goal_theta').value)
        gth = np.radians(gth_deg)

        dist = float(np.hypot(gx - pos.x, gy - pos.y))
        theta_err = self.wrap_pi(gth - yaw)

        #  DASHBOARD 
        line = f"X:{pos.x:6.3f} Y:{pos.y:6.3f} TH:{yaw_deg:7.1f} | GX:{gx:5.2f} GY:{gy:5.2f} GTH:{gth_deg:7.1f}"
        sys.stdout.write("\r" + line + "\033[K")
        sys.stdout.flush()

        if self.goal_reached: return

        cmd = Twist()

        # ORIENTATION 
        if dist <= self.xy_tol:
            cmd.linear.x = 0.0 
            if abs(theta_err) <= self.theta_tol:
                self.goal_reached = True
                self.cmd_pub.publish(Twist())
                sys.stdout.write("\n[DONE] Position and Theta Secured.\n")
                return
            else:
                # No more proportional fade-out. Just hit it with a constant 0.8 rad/s 
                # in the correct direction until the angle is perfect.
                cmd.angular.z = 0.8 if theta_err > 0 else -0.8
                self.cmd_pub.publish(cmd)
                return

        #  NAVIGATION 
        alpha = self.wrap_pi(np.arctan2(gy - pos.y, gx - pos.x) - yaw)
        reverse_mode = abs(alpha) > (np.pi / 2.0)
        
        if reverse_mode:
            alpha_used = self.wrap_pi(alpha - np.pi)
            beta_used = self.wrap_pi(gth - yaw - alpha_used)
            v_final = -float(np.clip(min(self.current_speed_effort, self.k_rho * dist), self.v_min, self.v_max))
        else:
            alpha_used = alpha
            beta_used = self.wrap_pi(gth - yaw - alpha_used)
            v_final = float(np.clip(min(self.current_speed_effort, self.k_rho * dist), self.v_min, self.v_max))

        omega = self.k_alpha * alpha_used + self.k_beta * beta_used
        cmd.linear.x = v_final
        cmd.angular.z = float(np.clip(omega, -self.max_omega, self.max_omega))
        self.cmd_pub.publish(cmd)

def main():
    rclpy.init(); rclpy.spin(LateralControlNode()); rclpy.shutdown()

if __name__ == '__main__':
    main()
