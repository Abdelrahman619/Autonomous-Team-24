import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64, Bool
import time

class SpeedControlNode(Node):
    def __init__(self):
        super().__init__('speed_control')
        
        # Parameters
        self.declare_parameter('desired_speed', 0.4)
        self.declare_parameter('use_hardware', False)
        
        # --- PHYSICAL CONSTANTS 
        self.K_MAP = 51.0  #editable for hardware !
        self.kp = 1.0 
        
        self.hardware_active = self.get_parameter('use_hardware').value
        self.current_v_actual = 0.0 
        self.total_dist_meters = 0.0
        self.last_time = time.time()

        # Publishers
        self.effort_pub = self.create_publisher(Float64, '/speed_effort', 10)
        self.dist_pub = self.create_publisher(Float64, '/hardware_dist_traveled', 10)
        
        # Subscribers
        self.create_subscription(Bool, '/hardware_status', self.status_cb, 10)
        self.create_subscription(Odometry, '/model/vehicle_blue/odometry', self.odom_cb, 10)
        self.create_subscription(Float64, '/actual_pps', self.pps_cb, 10)
        
        self.timer = self.create_timer(0.05, self.control_loop)
        self.get_logger().info(f"System Online: K_MAP set to {self.K_MAP} (3k pulses/meter)")

    def status_cb(self, msg):
        self.hardware_active = msg.data

    def odom_cb(self, msg):
        # In simulation mode, we use Gazebo speed ODOMETRY
        if not self.hardware_active:
            self.current_v_actual = msg.twist.twist.linear.x

    def pps_cb(self, msg):
        # In Hardware mode ENCODER
        if self.hardware_active:
            self.current_v_actual = msg.data / self.K_MAP
            
           
            now = time.time()
            dt = now - self.last_time
            self.total_dist_meters += abs(self.current_v_actual * dt)
            self.last_time = now
            
            
            dist_msg = Float64()
            dist_msg.data = self.total_dist_meters
            self.dist_pub.publish(dist_msg)

    def control_loop(self):
        v_desired = self.get_parameter('desired_speed').value
        error = v_desired - self.current_v_actual
        effort = Float64()
        effort.data = float(v_desired + (self.kp * error))
        self.effort_pub.publish(effort)

def main():
    rclpy.init(); rclpy.spin(SpeedControlNode()); rclpy.shutdown()
